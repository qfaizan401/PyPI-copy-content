# Copy Content
This package is an automated tool for coping multiple files one folder/directory to another with your desired extension.
## Installation
`pip install copy-content`
## How to use it
Note: Make sure that both current/src directory and target/dst directory must exist and have a valid path.
## License
© 2021 Muhammad Faizan Qureshi

This repository is licensed under the MIT license. See LICENSE for details.